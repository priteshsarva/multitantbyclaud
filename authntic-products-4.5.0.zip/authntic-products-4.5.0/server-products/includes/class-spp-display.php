<?php
if (!defined('ABSPATH')) exit;

/**
 * Renders managed-product images from the stored URL meta (featuredimg / imageUrl),
 * so images appear without importing 100k+ attachments. Theme-independent.
 */
class SPP_Display {

    public static function init() {
        add_filter('woocommerce_product_get_image', [__CLASS__, 'loop_image'], 10, 2);
        add_filter('post_thumbnail_html',            [__CLASS__, 'thumb_html'], 10, 5);
        // When the Flickity gallery module owns the single-product gallery, don't
        // also rewrite the single gallery here — SPP_Gallery renders it instead.
        if (get_option(SPP_Gallery::OPT_ENABLED) !== 'yes') {
            add_filter('woocommerce_single_product_image_thumbnail_html', [__CLASS__, 'single_html'], 10, 2);
        }
    }

    private static function is_managed($pid) {
        return $pid && get_post_meta($pid, SPP_MANAGED, true) === '1';
    }

    private static function featured($pid) {
        return (string) get_post_meta($pid, 'featuredimg', true);
    }

    private static function gallery($pid) {
        $raw = get_post_meta($pid, 'imageUrl', true);
        $imgs = [];
        if (is_string($raw) && $raw !== '') {
            $d = json_decode($raw, true);
            if (is_array($d)) $imgs = $d;
        }
        if (empty($imgs)) {
            $f = self::featured($pid);
            if ($f) $imgs = [$f];
        }
        return array_values(array_filter(array_map('strval', $imgs)));
    }

    /** WC loop image (shop/category/related) */
    public static function loop_image($html, $product) {
        if (!$product) return $html;
        $pid = $product->get_id();
        if (!self::is_managed($pid)) return $html;
        $url = self::featured($pid);
        if (!$url) return $html;

        $out = '<img src="' . esc_url($url) . '" alt="' . esc_attr($product->get_name()) . '" class="spp-img" loading="lazy" />';

        // Hover ("back") image — ported from flatsome-child content-product.php.
        // The second gallery image is shown on hover over the card. The classes
        // are Flatsome's own (show-on-hover / absolute / fill / back-image), so it
        // inherits the theme's hover behaviour; on other themes the extra img is
        // inert unless those classes exist. Desktop only, as in the original.
        $imgs = self::gallery($pid);
        if (count($imgs) >= 2 && $imgs[1] !== $url) {
            $out .= '<img src="' . esc_url($imgs[1]) . '"'
                  . ' alt="' . esc_attr__('Alternative view', 'woocommerce') . '"'
                  . ' class="spp-img back-image show-on-hover absolute fill hide-for-small"'
                  . ' aria-hidden="true" loading="lazy" decoding="async" />';
        }
        return $out;
    }

    /** generic thumbnail (widgets, blocks) */
    public static function thumb_html($html, $post_id, $thumb_id, $size, $attr) {
        if (get_post_type($post_id) !== 'product' || !self::is_managed($post_id)) return $html;
        $url = self::featured($post_id);
        if (!$url) return $html;
        return '<img src="' . esc_url($url) . '" class="spp-img" loading="lazy" />';
    }

    /** single product gallery — emit one slide per image URL */
    public static function single_html($html, $attachment_id) {
        $pid = get_the_ID();
        if (!self::is_managed($pid)) return $html;

        static $emitted = [];
        if (isset($emitted[$pid])) return ''; // we render the whole gallery once, on first call
        $emitted[$pid] = true;

        $imgs = self::gallery($pid);
        if (empty($imgs)) return $html;

        $out = '';
        foreach ($imgs as $src) {
            $out .= '<div class="woocommerce-product-gallery__image spp-gallery-image">'
                  . '<a href="' . esc_url($src) . '"><img src="' . esc_url($src) . '" class="spp-img" loading="lazy" alt="" /></a>'
                  . '</div>';
        }
        return $out;
    }
}
